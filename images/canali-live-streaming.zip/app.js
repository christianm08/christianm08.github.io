// StreamHub App - Versione semplificata e funzionante
let currentServer = 'dlhd.click';
let currentFilter = 'all';

const channels = [
    {"name": "EuroSport 1", "stream": "stream-878.php", "category": "sport", "icon": "⚽"},
    {"name": "EuroSport 2", "stream": "stream-879.php", "category": "sport", "icon": "🏆"},
    {"name": "Sky Cinema Action", "stream": "stream-861.php", "category": "cinema", "icon": "🎬"},
    {"name": "Sky Cinema Collection", "stream": "stream-859.php", "category": "cinema", "icon": "🎭"},
    {"name": "Sky Cinema Comedy", "stream": "stream-862.php", "category": "cinema", "icon": "😄"},
    {"name": "Sky Cinema Family", "stream": "stream-865.php", "category": "cinema", "icon": "👨‍👩‍👧‍👦"},
    {"name": "Sky Cinema Uno", "stream": "stream-860.php", "category": "cinema", "icon": "🎥"},
    {"name": "Sky Cinema Uno +24", "stream": "stream-863.php", "category": "cinema", "icon": "🎥"},
    {"name": "Sky Cinema Due +24", "stream": "stream-866.php", "category": "cinema", "icon": "🎥"},
    {"name": "Sky Cinema Drama", "stream": "stream-867.php", "category": "cinema", "icon": "🎭"},
    {"name": "Sky Cinema Romance", "stream": "stream-864.php", "category": "cinema", "icon": "💕"},
    {"name": "Sky Cinema Suspense", "stream": "stream-868.php", "category": "cinema", "icon": "😱"},
    {"name": "Sky Serie", "stream": "stream-880.php", "category": "tv", "icon": "📺"},
    {"name": "Sky Calcio 1", "stream": "stream-871.php", "category": "calcio", "icon": "⚽"},
    {"name": "Sky Calcio 2", "stream": "stream-872.php", "category": "calcio", "icon": "⚽"},
    {"name": "Sky Calcio 3", "stream": "stream-873.php", "category": "calcio", "icon": "⚽"},
    {"name": "Sky Calcio 4", "stream": "stream-874.php", "category": "calcio", "icon": "⚽"},
    {"name": "Sky Calcio 5", "stream": "stream-875.php", "category": "calcio", "icon": "⚽"},
    {"name": "Sky Calcio 6", "stream": "stream-876.php", "category": "calcio", "icon": "⚽"},
    {"name": "Sky Sport 24", "stream": "stream-869.php", "category": "sport", "icon": "📺"},
    {"name": "Sky Sport Arena", "stream": "stream-462.php", "category": "sport", "icon": "🏟️"},
    {"name": "Sky Sport Calcio", "stream": "stream-870.php", "category": "sport", "icon": "⚽"},
    {"name": "Sky Sport Football", "stream": "stream-460.php", "category": "sport", "icon": "🏈"},
    {"name": "Sky Sport F1", "stream": "stream-577.php", "category": "sport", "icon": "🏎️"},
    {"name": "Sky Sport MotoGP", "stream": "stream-575.php", "category": "sport", "icon": "🏍️"},
    {"name": "Sky Sport Tennis", "stream": "stream-576.php", "category": "sport", "icon": "🎾"},
    {"name": "Sky Sport UNO", "stream": "stream-461.php", "category": "sport", "icon": "🏆"},
    {"name": "Sky Sport Golf", "stream": "stream-574.php", "category": "sport", "icon": "⛳"},
    {"name": "Sky UNO", "stream": "stream-881.php", "category": "tv", "icon": "📺"},
    {"name": "Zona DAZN", "stream": "stream-877.php", "category": "sport", "icon": "📱"}
];

function getCategoryDisplayName(category) {
    const categoryNames = {
        'sport': 'Sport',
        'cinema': 'Cinema',
        'calcio': 'Calcio',
        'tv': 'TV'
    };
    return categoryNames[category] || category;
}

function renderChannels() {
    const grid = document.getElementById('channels-grid');
    if (!grid) return;
    
    grid.innerHTML = '';

    channels.forEach((channel, index) => {
        const card = document.createElement('div');
        card.className = 'channel-card';
        card.setAttribute('data-category', channel.category);
        card.style.animationDelay = `${index * 0.05}s`;
        card.setAttribute('data-channel-name', channel.name);
        card.setAttribute('data-stream', channel.stream);

        card.innerHTML = `
            <div class="channel-icon">${channel.icon}</div>
            <h3 class="channel-name">${channel.name}</h3>
            <div class="channel-category">${getCategoryDisplayName(channel.category)}</div>
        `;

        grid.appendChild(card);
    });

    // Add click events to all channel cards
    attachChannelEvents();
    
    // Animate cards in
    setTimeout(() => {
        const cards = document.querySelectorAll('.channel-card');
        cards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('visible');
            }, index * 50);
        });
    }, 100);
}

function attachChannelEvents() {
    const cards = document.querySelectorAll('.channel-card');
    cards.forEach(card => {
        card.addEventListener('click', function() {
            const channelName = this.getAttribute('data-channel-name');
            const streamFile = this.getAttribute('data-stream');
            openPlayer(channelName, streamFile);
        });
    });
}

function openPlayer(channelName, streamFile) {
    console.log('Opening player for:', channelName);
    
    // Show loading
    showLoading();
    
    // Set channel title
    const titleElement = document.getElementById('channel-title');
    if (titleElement) {
        titleElement.textContent = channelName;
    }
    
    // Build URL
    const streamUrl = `https://${currentServer}/embed/${streamFile}`;
    console.log('Stream URL:', streamUrl);
    
    setTimeout(() => {
        // Set iframe src
        const playerFrame = document.getElementById('player-frame');
        if (playerFrame) {
            playerFrame.src = streamUrl;
        }
        
        // Hide loading and show modal
        hideLoading();
        showModal();
    }, 1000);
}

function closePlayer() {
    console.log('Closing player');
    const modal = document.getElementById('player-modal');
    const playerFrame = document.getElementById('player-frame');
    
    if (modal) {
        modal.classList.remove('visible');
        setTimeout(() => {
            modal.classList.add('hidden');
            if (playerFrame) {
                playerFrame.src = '';
            }
        }, 300);
    }
}

function showModal() {
    const modal = document.getElementById('player-modal');
    if (modal) {
        modal.classList.remove('hidden');
        setTimeout(() => {
            modal.classList.add('visible');
        }, 10);
    }
}

function showLoading() {
    const loading = document.getElementById('loading-overlay');
    if (loading) {
        loading.classList.remove('hidden');
        setTimeout(() => {
            loading.classList.add('visible');
        }, 10);
    }
}

function hideLoading() {
    const loading = document.getElementById('loading-overlay');
    if (loading) {
        loading.classList.remove('visible');
        setTimeout(() => {
            loading.classList.add('hidden');
        }, 300);
    }
}

function handleFilterClick(category) {
    console.log('Filtering by:', category);
    currentFilter = category;
    
    // Update active button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    const activeBtn = document.querySelector(`[data-category="${category}"]`);
    if (activeBtn) {
        activeBtn.classList.add('active');
    }
    
    // Filter cards
    const cards = document.querySelectorAll('.channel-card');
    cards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        const shouldShow = category === 'all' || cardCategory === category;
        
        if (shouldShow) {
            card.style.display = 'block';
            card.classList.remove('filtered-out');
        } else {
            card.style.display = 'none';
            card.classList.add('filtered-out');
        }
    });
}

function handleServerChange(serverValue) {
    currentServer = serverValue;
    console.log('Server changed to:', currentServer);
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎬 StreamHub Loading...');
    
    // Render channels
    renderChannels();
    
    // Server selector event
    const serverSelect = document.getElementById('server-select');
    if (serverSelect) {
        serverSelect.addEventListener('change', function() {
            handleServerChange(this.value);
        });
    }
    
    // Filter button events
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            handleFilterClick(category);
        });
    });
    
    // Modal close events
    const closeBtn = document.getElementById('close-modal');
    if (closeBtn) {
        closeBtn.addEventListener('click', closePlayer);
    }
    
    const backdrop = document.getElementById('modal-backdrop');
    if (backdrop) {
        backdrop.addEventListener('click', closePlayer);
    }
    
    // Escape key to close modal
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closePlayer();
        }
    });
    
    console.log('✅ StreamHub initialized successfully!');
    console.log('📺 Available channels:', channels.length);
    console.log('🔧 Default server:', currentServer);
});